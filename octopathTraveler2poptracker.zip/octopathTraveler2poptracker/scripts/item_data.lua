ITEM_GROUPS = {
	["Traveler"] = {"ochette", "castti", "temenos", "osvald", "partitio", "agnea", "throné", "hikari"},
	["Region"] = {"progressive_totohaha", "progressive_harborlands", "progressive_brightlands", "progressive_winterlands", "progressive_wildlands", "progressive_leaflands", "progressive_crestlands", "progressive_hinoeuma", "progressive_sundering_sea"},
	["Dungeon Map"] = {"abandoned_waterway_map", "infernal_castle_map", "cavern_of_waves_map", "curious_nest_map", "decaying_temple_map", "five-tiered_tower_map", "forsaken_graveyard_map", "house_wellows_manor_map", "ivory_ravine_map", "lair_of_the_usurper_map", "nameless_isle_map", "old_clock_tower_map", "quicksand_gaol_map", "ruffians_hideout_map", "seat_of_the_water_sprite_map", "shipwreck_of_the_empress_map", "sinking_ruins_map", "starfall_spring_map", "sunken_maw_map", "unfinished_tunnel_map"},
	["Chapter"] = {"progressive_ochette_chapter", "progressive_castti_chapter", "progressive_throné_chapter", "progressive_osvald_chapter", "progressive_partitio_chapter", "progressive_agnea_chapter", "progressive_temenos_chapter", "progressive_hikari_chapter"},
	["Scent of Commerce"] = {"scent_of_commerce_tropuhopu", "scent_of_commerce_winterbloom", "scent_of_commerce_sai"}
}


ITEM_VALUES = {

}


STAGE_MAPPINGS = {
	["Example_Choice"] = {[0] = 0, [1] = 1}
}